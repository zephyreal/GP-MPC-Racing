function next=v8_predict(X,U,c,model)
next=v8_step(X,U,c.dt,'nominal',c.integrationStep);
next(4:6,:)=next(4:6,:)+v8_correction(model,X,U);
end
