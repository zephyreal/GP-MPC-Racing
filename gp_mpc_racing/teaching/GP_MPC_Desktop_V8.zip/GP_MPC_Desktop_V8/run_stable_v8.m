function out=run_stable_v8(usercfg)
% Independent entry point: no NMPC class/path cache dependency.
if nargin<1,usercfg=struct();end
c=v8_defaults(usercfg);m=v8_map(c);K=floor(c.maxSimTime/c.dt);
active=[];candidate=[];badRun=0;lapRollback=false;job=[];ready=[];revision=0;
x=[5;0;0;c.initialSpeed;0;0;0];[x(7),~]=v8_project(m,x);last=[0;0;x(4)];
% JIT warm-up uses copies of the initial state, not simulation steps.
warmReport=v8_warmup(x,last,m,c);warmSeconds=warmReport.seconds;
out=struct('cfg',c,'mode','stable_v8','t',(0:K)*c.dt,'x',NaN(7,K+1), ...
    'u',NaN(3,K),'control_seconds',NaN(1,K),'solve_seconds',NaN(1,K), ...
    'loop_seconds',NaN(1,K),'plant_seconds',NaN(1,K),'outside',false(1,K), ...
    'clearance',NaN(1,K),'contour_error',NaN(1,K),'fallback',false(1,K), ...
    'feasible',false(1,K),'timedOut',false(1,K),'predictedClearance',NaN(1,K), ...
    'prediction',NaN(7,c.horizon+1,K),'nominal_next',NaN(7,K), ...
    'prediction_error',NaN(6,K),'z',NaN(5,K),'residual',NaN(K,3), ...
    'progress',zeros(1,K+1),'steps',0,'stopped_reason','','laps',struct([]), ...
    'track_c',m.track_c,'track_l',m.track_l,'track_r',m.track_r, ...
    'warmup_seconds',warmSeconds);
out.warmup_report=warmReport;
out.console_seconds=zeros(1,K);out.observation_seconds=zeros(1,K);out.rls_seconds=zeros(1,K);out.validation_seconds=zeros(1,K);out.validation_queue_seconds=zeros(1,K);
out.switch_seconds=zeros(1,K);out.validation_deferred=false(1,K);out.rls_skipped=false(1,K);
out.decision_seconds=NaN(1,K);out.learning_seconds=zeros(1,K);
out.modelActive=false(1,K);out.modelRollback=false(1,K);
out.feasibleCount=zeros(1,K);out.screenComplete=false(1,K);
out.rejectCounts=zeros(7,K);out.rejectMask=zeros(18,K,'uint16');
out.actualEnvelopeViolation=false(1,K);out.actualMotion=NaN(4,K);out.corrected_error=NaN(3,K);
out.learning_history=struct([]);out.promoted_models={};
out.rejectLabels={'nonfinite','minimum_speed','body_beta','front_slip','rear_slip','yaw_proxy','boundary'};
out.x(:,1)=x;ui=[];if c.live,ui=v8_dashboard('init',m);end
fprintf('V8 full-size | %d laps | dt %.3fs | speed %.1f m/s | budget %.0f ms | deadline %.0f ms\n', ...
    c.laps,c.dt,c.speedMax,1000*c.searchBudget,1000*c.deadline);
wall=tic;total=0;lastCross=0;lapStart=1;
for k=1:K
    if c.live && (~isgraphics(ui.fig) || getappdata(ui.fig,'stopRequested'))
        out.stopped_reason='Stopped by user';break;
    end
    lapCompleted=false;loopClock=tic;controlClock=tic;
    out.modelActive(k)=~isempty(active);
    [u,pred,info]=v8_control(x,last,m,c,active);
    % Final command integrity check belongs to timed controller work.
    if any(~isfinite(u)) || abs(u(1))>c.steerMax+1e-10 || abs(u(2))>1
        [u,~]=v8_feedback(x,last,m,c,0,0.55,1);info.fallback=true;info.feasible=false;
    end
    out.decision_seconds(k)=toc(controlClock);out.control_seconds(k)=out.decision_seconds(k);
    out.solve_seconds(k)=info.seconds;out.feasibleCount(k)=info.feasibleCount;
    out.screenComplete(k)=info.screenComplete;out.rejectCounts(:,k)=info.rejectCounts;out.rejectMask(:,k)=info.rejectMask;
    out.u(:,k)=u;out.fallback(k)=info.fallback;out.feasible(k)=info.feasible;
    out.timedOut(k)=info.timedOut;out.predictedClearance(k)=info.predictedClearance;
    out.prediction(:,1:size(pred,2),k)=pred;
    plantClock=tic;
    % Check footprint throughout the held-control interval, not just its end.
    next=x;minClear=inf;n=ceil(c.dt/c.integrationStep);reason='';
    for j=1:n
        next=v8_step(next,u,c.dt/n,'true',c.integrationStep);
        if any(~isfinite(next)) || next(4)<=0 || abs(atan2(next(5),next(4)))>pi/3
            reason='Invalid vehicle state or excessive sideslip';break;
        end
        cl=v8_clearance(m,next,c);minClear=min(minClear,cl);
    end
    out.plant_seconds(k)=toc(plantClock);
    learningClock=tic;
    nominal=v8_step(x,u,c.dt,'nominal',c.integrationStep);
    out.nominal_next(:,k)=nominal;out.prediction_error(:,k)=next(1:6)-nominal(1:6);
    out.z(:,k)=[x(4:6);u(1:2)];out.residual(k,:)=(next(4:6)-nominal(4:6))';
    if ~isempty(reason),out.prediction_error(:,k)=NaN;out.residual(k,:)=NaN;end
    out.steps=k;out.x(:,k+1)=next;out.clearance(k)=minClear;out.outside(k)=minClear<0;
    if ~isempty(reason)
        out.learning_seconds(k)=toc(learningClock);out.control_seconds(k)=out.decision_seconds(k)+out.learning_seconds(k);
        out.stopped_reason=reason;out.loop_seconds(k)=toc(loopClock);break;
    end
    [next(7),ey]=v8_project(m,next);out.x(:,k+1)=next;out.contour_error(k)=ey;
    [actualBad,motion]=v8_stability(next,u,minClear,c);out.actualMotion(:,k)=motion;
    out.actualEnvelopeViolation(k)=any(actualBad);
    target=out.residual(k,:)';correction=v8_correction(active,x,u);
    out.corrected_error(:,k)=target-correction;
    if ~isempty(active)
        baseError=norm(target./[0.05;0.02;0.02]);
        correctedError=norm((target-correction)./[0.05;0.02;0.02]);
        if correctedError>1.5*baseError+0.05,badRun=badRun+1;else,badRun=0;end
        if minClear<c.edgeMargin+0.2 || any(actualBad) || badRun>=3
            active=[];revision=revision+1;ready=[];badRun=0;lapRollback=true;out.modelRollback(k)=true;
        end
    end
    out.observation_seconds(k)=toc(learningClock);
    % Odd laps train online. Even laps are entirely held out, candidate frozen.
    lapNumber=numel(out.laps)+1;
    if c.learn && mod(lapNumber,2)==1 && minClear>=c.edgeMargin && ~any(actualBad)
        if out.decision_seconds(k)+toc(learningClock)+c.deadlineReserve+0.002<c.deadline && toc(learningClock)<c.learningBudget-0.002
            partClock=tic;candidate=v8_rls(candidate,x,u,target,c);out.rls_seconds(k)=toc(partClock);
        else
            out.rls_skipped(k)=true;
        end
    end
    % At most one validation work unit per control step; snapshots remain frozen.
    if ~isempty(job)
        if job.revision~=revision || minClear<c.edgeMargin+0.2 || any(actualBad)
            job.phase=3;job.event.accepted=false;job.event.reason='Cancelled after baseline or state change';
        elseif job.phase~=3
            if out.decision_seconds(k)+toc(learningClock)+c.validationStepBudget+c.deadlineReserve<c.deadline && ...
                    toc(learningClock)+c.validationStepBudget<c.learningBudget
                partClock=tic;job=v8_validation_tick(job,m,c);out.validation_seconds(k)=toc(partClock);
            else
                out.validation_deferred(k)=true;
            end
        end
        if job.phase==3
            event=job.event;event.completed_step=k;event.calls=job.calls;
            event.maxChunkSeconds=job.maxChunkSeconds;event.promoted=false;event.promoted_lap=NaN;
            if isempty(out.learning_history),out.learning_history=event;else,out.learning_history(end+1)=event;end
            if event.accepted
                ready=struct('model',job.candidate,'revision',revision,'historyIndex',numel(out.learning_history));
            end
            job=[];
        end
    end
    out.learning_seconds(k)=toc(learningClock);
    out.control_seconds(k)=out.decision_seconds(k)+out.learning_seconds(k);
    ds=mod(next(7)-x(7)+m.L/2,m.L)-m.L/2;
    previous=total;total=total+ds;out.progress(k+1)=total;
    if c.stopOnViolation && minClear<0
        out.stopped_reason='Footprint boundary violation; stopped for diagnosis';
        out.loop_seconds(k)=toc(loopClock);break;
    end
    completed=numel(out.laps);
    if total>=(completed+1)*m.L && ds>0
        crossing=out.t(k)+c.dt*((completed+1)*m.L-previous)/ds;span=lapStart:k;
        promoted=false;learningReason='Learning disabled';
        % Commit only at a lap boundary, and only if the validated baseline is still current.
        partClock=tic;
        if ~isempty(ready)
            if ready.revision==revision && ~lapRollback && ~any(out.outside(span)) && ...
                    ~any(out.actualEnvelopeViolation(span)) && min(out.clearance(span))>=c.edgeMargin
                active=ready.model;revision=revision+1;badRun=0;promoted=true;
                out.promoted_models{end+1}=active;
                out.learning_history(ready.historyIndex).promoted=true;
                out.learning_history(ready.historyIndex).promoted_lap=completed+1;
            end
            ready=[];
        end
        out.switch_seconds(k)=toc(partClock);
        if c.learn
            if promoted
                learningReason='Incrementally validated model committed for next lap';
            elseif mod(completed+1,2)==1
                learningReason='Training lap completed; validation may still be pending';
            elseif lapRollback || any(out.outside(span)) || min(out.clearance(span))<c.edgeMargin || any(out.actualEnvelopeViolation(span))
                learningReason='No validation queued after state/clearance failure';
            elseif completed+1>=c.laps
                learningReason='Final lap: no new validation queued';
            elseif ~isempty(job)
                learningReason='Previous frozen validation job still pending';
            else
                partClock=tic;
                job=v8_validation_begin(candidate,active,out,span,c,revision,completed+1);
                out.validation_queue_seconds(k)=toc(partClock);
                learningReason='Frozen validation job queued; continue control next step';
            end
        end
        out.learning_seconds(k)=toc(learningClock);
        out.control_seconds(k)=out.decision_seconds(k)+out.learning_seconds(k);
        lap=struct('index',completed+1,'seconds',crossing-lastCross, ...
            'lateralRMSE',sqrt(mean(out.contour_error(span).^2)), ...
            'outsideSamples',sum(out.outside(span)),'minClearance',min(out.clearance(span)), ...
            'fallbackSamples',sum(out.fallback(span)), ...
            'deadlineMisses',sum(out.control_seconds(span)>c.deadline), ...
            'modelUsedSamples',sum(out.modelActive(span)),'modelRollbacks',sum(out.modelRollback(span)), ...
            'promotedNext',promoted,'learningReason',learningReason);
        if isempty(out.laps),out.laps=lap;else,out.laps(end+1)=lap;end
        lastCross=crossing;lapStart=k+1;lapRollback=false;
        lapCompleted=true;
    end
    out.learning_seconds(k)=toc(learningClock);
    out.control_seconds(k)=out.decision_seconds(k)+out.learning_seconds(k);
    if lapCompleted
        lap.deadlineMisses=sum(out.control_seconds(span)>c.deadline);out.laps(end).deadlineMisses=lap.deadlineMisses;
        consoleClock=tic;
        fprintf('Lap %d: %.2fs | RMSE %.3fm | min clearance %.3fm | outside %d | fallback %d | late %d\n', ...
            lap.index,lap.seconds,lap.lateralRMSE,lap.minClearance,lap.outsideSamples,lap.fallbackSamples,lap.deadlineMisses);
        fprintf('  model used %d | rollback %d | promote %d | %s\n', ...
            lap.modelUsedSamples,lap.modelRollbacks,lap.promotedNext,lap.learningReason);
        out.console_seconds(k)=toc(consoleClock);
    end
    if c.live && (mod(k,c.drawEvery)==0 || numel(out.laps)>=c.laps)
        status=sprintf('V8 | lap %d/%d | v %.2f m/s | control %.1f ms | clearance %.2f m | backup %d | learned %d', ...
            min(numel(out.laps)+1,c.laps),c.laps,hypot(next(4),next(5)), ...
            1000*out.control_seconds(k),minClear,info.fallback,out.modelActive(k));
        v8_dashboard('update',ui,out,k,pred,status);
    end
    out.loop_seconds(k)=toc(loopClock);x=next;last=u;
    if numel(out.laps)>=c.laps,out.stopped_reason='Requested laps completed';break;end
end
if isempty(out.stopped_reason),out.stopped_reason='Maximum simulation time reached';end
out.wall_seconds=toc(wall);n=out.steps;
% Trim preallocation so collected data can be used without NaN-tail filtering.
stateFields={'x','t','progress'};
for i=1:numel(stateFields),name=stateFields{i};out.(name)=out.(name)(:,1:n+1);end
stepFields={'u','control_seconds','solve_seconds','loop_seconds','plant_seconds','outside', ...
    'clearance','contour_error','fallback','feasible','timedOut','predictedClearance', ...
    'nominal_next','prediction_error','z','decision_seconds','learning_seconds', ...
    'modelActive','modelRollback','feasibleCount','screenComplete','rejectCounts','rejectMask', ...
    'actualMotion','actualEnvelopeViolation','corrected_error','rls_seconds','validation_seconds', ...
    'validation_queue_seconds','switch_seconds','validation_deferred','rls_skipped','console_seconds','observation_seconds'};
for i=1:numel(stepFields),name=stepFields{i};out.(name)=out.(name)(:,1:n);end
out.prediction=out.prediction(:,:,1:n);out.residual=out.residual(1:n,:);
out.final_active_model=active;out.final_candidate_model=candidate;
out.validation_pending=~isempty(job);out.validated_waiting_commit=~isempty(ready);
out.summary=v8_summary(out);
disp(out.summary);fprintf('Finished: %s\n',out.stopped_reason);
if c.live && isgraphics(ui.fig),v8_dashboard('message',ui,['Finished: ' out.stopped_reason]);end
if c.saveResults
    root=fileparts(mfilename('fullpath'));folder=fullfile(root,'results');
    if ~isfolder(folder),mkdir(folder);end
    if c.learn,tag='learn';else,tag='baseline';end
    name=['v8_' tag '_' c.controller '_' datestr(now,'yyyymmdd_HHMMSS_FFF')];
    save(fullfile(folder,[name '.mat']),'out');
    if ~isempty(out.laps),writetable(struct2table(out.laps),fullfile(folder,[name '_laps.csv']));end
    fprintf('Saved %s\n',fullfile(folder,[name '.mat']));
end
end
