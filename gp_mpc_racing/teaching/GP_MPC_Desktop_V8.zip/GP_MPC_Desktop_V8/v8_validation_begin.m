function job=v8_validation_begin(candidate,active,out,span,c,revision,lap)
% Snapshot only bounded validation data, never retain the entire run log.
event=struct('accepted',false,'reason','Pending','oldError',NaN,'newError',NaN, ...
    'oldRolloutError',NaN,'newRolloutError',NaN,'seconds',0,'lap',lap);
job=struct('candidate',candidate,'baseline',active,'revision',revision,'phase',1, ...
    'event',event,'cursor',1,'rollStep',0,'a',zeros(3,1),'b',zeros(3,1), ...
    'ae',0,'be',0,'calls',0,'maxChunkSeconds',0);
if isempty(candidate) || candidate.count<100 || numel(span)<max(40,c.horizon)
    job.phase=3;job.event.reason='Not enough data';return;
end
ids=span(unique(round(linspace(1,numel(span),min(160,numel(span))))));
job.X=out.x(:,ids);job.U=out.u(:,ids);job.Y=out.residual(ids,:)';
starts=span(unique(round(linspace(1,numel(span)-c.horizon+1,3))));
job.oldX=out.x(:,starts);job.newX=job.oldX;
job.rollU=zeros(3,numel(starts),c.horizon);job.actual=zeros(6,numel(starts),c.horizon);
for j=1:c.horizon
    job.rollU(:,:,j)=out.u(:,starts+j-1);job.actual(:,:,j)=out.x(1:6,starts+j);
end
end
