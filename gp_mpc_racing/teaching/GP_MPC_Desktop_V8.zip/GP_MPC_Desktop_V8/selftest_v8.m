function selftest_v8
% Run once before the live demo. No Optimization / Statistics Toolbox needed.
root=fileparts(mfilename('fullpath'));addpath(root,'-begin');
refpath=fullfile(root,'validation_reference');addpath(refpath);
cleanup=onCleanup(@() rmpath(refpath)); %#ok<NASGU>
c=v8_defaults(struct('live',false,'saveResults',false));m=v8_map(c);
nom=V8ReferenceNominal([],[]);truth=V8ReferenceTrue([],[]);
rng(7);B=24;
X=[10*randn(2,B);randn(1,B);2+8*rand(1,B);0.1*randn(2,B);zeros(1,B)];
U=[0.2*randn(1,B);2*rand(1,B)-1;5*ones(1,B)];
for kind={'nominal','true'}
    if strcmp(kind{1},'nominal'),model=nom;else,model=truth;end
    actual=v8_step(X,U,c.dt,kind{1},c.integrationStep);expected=X;
    n=ceil(c.dt/c.integrationStep);h=c.dt/n;
    for j=1:B
        for k=1:n
            y=expected(:,j);a=model.f(y,U(:,j));
            expected(:,j)=y+h*model.f(y+0.5*h*a,U(:,j));
        end
    end
    assert(max(abs(actual(:)-expected(:)))<1e-10,'Original model equivalence failed.');
end
% Endpoints, seam and batch projection.
[s,e]=v8_project(m,m.P(:,[1 30 end]));
assert(max(abs(e))<1e-10 && all(isfinite(s)));
x=[5;0;0;3;0;0;0];last=[0;0;3];
cl=v8_clearance(m,x,c);assert(isfinite(cl) && cl>c.edgeMargin);
% Force a timeout. It must return bounded backup commands, not a partial search.
forced=c;forced.searchBudget=1e-12;
[u,~,info]=v8_control(x,last,m,forced);
assert(info.fallback && info.timedOut && ~info.feasible);
assert(all(isfinite(u)) && abs(u(1))<=c.steerMax && abs(u(2))<=1);
% Kinematic low-speed turning should not be rejected just for body beta.
y=[0;0;0;1;0.35;0.35/1.5;0];steer=atan2(y(5)+0.9*y(6),y(4));
[bad,~]=v8_stability(y,[steer;0;1],2,c);
assert(~any(bad),'Low-speed rolling motion incorrectly rejected.');
y(5)=2;[bad,~]=v8_stability(y,[0;0;1],2,c);
assert(any(bad(3:5)),'Excessive slip was not rejected.');
model=[];target=[0.02;-0.01;0.005];
for j=1:120,model=v8_rls(model,x,last,target,c);end
frozen=model;d=v8_correction(model,x,last);
assert(all(isfinite(d)) && norm(target-d)<norm(target));
assert(isequal(model,frozen),'Predictor modified a frozen model.');
% Compare incremental validation with V7 batch mathematics on frozen data.
testCfg=c;testCfg.validationStepBudget=inf;testCfg.learningBudget=inf;
fake=struct('x',repmat(x,1,161),'u',repmat(last,1,160), ...
    'residual',repmat(target',160,1));
job=v8_validation_begin(model,[],fake,1:160,testCfg,0,2);
snapshot=job.candidate;model=v8_rls(model,x,last,-target,c);
assert(isequal(job.candidate,snapshot),'Validation snapshot changed with trainer.');
job=v8_validation_tick(job,m,testCfg);
assert(job.phase==1 && job.cursor==17 && job.calls==1,'Work was not bounded to one chunk.');
for j=1:50
    if job.phase==3,break;end
    job=v8_validation_tick(job,m,testCfg);
end
reference=v8_validate_reference(snapshot,[],fake,1:160,m,testCfg);
assert(job.phase==3 && job.event.accepted==reference.accepted);
assert(abs(job.event.newError-reference.newError)<1e-10);
assert(job.calls<=10+c.horizon,'Incremental work count exceeded expected bound.');
% A too-slow chunk is rejected, not promoted or silently omitted from timing.
forced=testCfg;forced.validationStepBudget=1e-12;
slow=v8_validation_begin(snapshot,[],fake,1:160,forced,0,2);
slow=v8_validation_tick(slow,m,forced);
assert(slow.phase==3 && ~slow.event.accepted && slow.event.seconds>0);
% Verify short execution, summaries, and array dimensions without a GUI.
out=run_stable_v8(struct('live',false,'saveResults',false,'maxSimTime',0.6));
assert(out.steps==4 && size(out.x,2)==5 && size(out.u,2)==4);
assert(all(isfinite(out.x(:))) && ~any(out.outside));
fprintf('V8 self-test passed: model equivalence, geometry, forced timeout, short run.\n');
end
