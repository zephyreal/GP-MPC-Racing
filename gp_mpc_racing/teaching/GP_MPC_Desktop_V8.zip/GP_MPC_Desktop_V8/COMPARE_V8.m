% Same physical model, initial state, speed, cost and integration in both runs.
root=fileparts(mfilename('fullpath'));addpath(root,'-begin');
baseline=run_stable_v8(struct('laps',6,'learn',false,'live',false));
learned=run_stable_v8(struct('laps',6,'learn',true,'live',false));
disp('Baseline:');disp(baseline.summary);
disp('Learning:');disp(learned.summary);
