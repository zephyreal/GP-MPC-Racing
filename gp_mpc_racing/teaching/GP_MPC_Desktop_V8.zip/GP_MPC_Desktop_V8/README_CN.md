# V8：学习验证分步执行与完整预热

这是在 V7 上针对计算尖峰的结构性改进。车辆、赛道、速度、候选控制器、RLS 特征、残差幅值限制、道路余量和候选接纳标准保持不变。不是 1:43 版本。

用户 V7 实测：6 圈零检测越界，常规控制约 5.57 ms，但一次总控制计算达到 330.82 ms、学习相关计算达到 323.59 ms。当前未收到该次 V7 的完整 MAT，不能确定尖峰发生于递推更新、验证、首次调用还是其他操作。V8 不能被描述为已经定位并消除了根因。

## 直接运行

解压到独立目录，将 MATLAB 当前目录切换过去：

```matlab
selftest_v8
START_LEARNING_V8
```

默认实时显示 6 圈，结束后自动输出 summary 和最慢 10 个步骤的分项计时表。

直接调用：

```matlab
out = run_stable_v8(struct('laps',6,'learn',true,'live',true));
disp(out.summary)
diagnose_timing_v8(out)
```

完成后建议返回汇总、分项计时表和 MAT 文件。V7 的 MAT 也可以用 `diagnose_timing_v8('完整文件路径.mat')` 查看已有的总时间和学习时间；V7 没有记录的分项显示 NaN，不会推测补齐。

无学习对照：

```matlab
baseline = run_stable_v8(struct('laps',6,'learn',false,'live',true));
```

不需要旧版本文件或额外 MATLAB 工具箱。标准 MATLAB R2018b 或更新版本；当前环境没有 MATLAB/Octave，未执行 MATLAB 自检或实测时间。

## 关键改动

### 1. 取消圈末整批验证

偶数圈结束时只冻结一个候选模型、当前活动模型及少量留出数据，不再执行完整预测验证。数据快照最多 160 个一步样本，加 3 条 12 步历史控制序列。

之后每个控制周期最多完成一个工作单元：

- 一步验证阶段：最多处理 16 个样本；最多 10 次。
- 多步验证阶段：3 条序列同时推进 1 步；共 12 次。

因此成功任务通常需要 22 次控制周期，而不是集中在圈末。工作单元内部不通过循环清空整个任务。时间余量不足时延后，不阻塞控制等待完成。递推训练若时间不足也跳过当前样本并计数。

每个验证工作单元的软预算默认 5 ms。单次调用超过预算就放弃此次候选验证、记录实际耗时；它不能中断已发生的函数调用，仍不是硬实时保证。

### 2. 冻结快照，避免训练污染验证

奇数圈仍更新候选，偶数圈仍整圈留出。处理留出数据时使用队列建立时冻结的模型快照，不使用下一圈继续训练后的候选。

验证通过后只进入“等待切换”状态，到圈边界才启用。期间如果旧活动模型被回滚，或验证任务观察到状态/道路余量异常，会取消过期任务。切换时再次检查对应模型版本和本圈运行情况。

典型时序：第 1 圈训练 → 第 2 圈留出并建立任务 → 第 3 圈分步验证 → 第 4 圈开始使用通过验证的模型。6 圈中模型使用比例可能约为一半，低于 V7 的约三分之二，这是调度改变，不是学习失效。

最后一圈不再建立没有后续执行机会的新验证任务。提前停止时可能留有未完成任务或等待切换的模型，summary 会明确标记。

### 3. 完整预热

在模拟车辆开始运动之前，使用独立合成数据预热：

- 递推更新与残差预测；
- 无学习模型/有学习模型的控制路径；
- 验证快照建立、一步验证、多步重放。

预热数据和拟合模型不会进入真实训练器，不推进模拟状态。预热时间单独记录为 `warmup_seconds` 和 `warmup_report`。只在启动预热内部关闭验证单元超时拒绝，以确保该路径真正运行完；正式循环仍严格记录全部超时。没有删除或截断任何正式控制样本。

这降低首次调用开销进入运行循环的可能性，但不是所有 MATLAB/JIT/操作系统行为的上界证明。

### 4. 分项计时

正式 `control_seconds = decision_seconds + learning_seconds`，learning 时间包含观测后处理、名义预测、残差、RLS、验证、模型切换以及相关计算记账。

新增：

- `observation_seconds`：名义预测、残差计算、实际状态和模型误差监测等。
- `rls_seconds`：一次递推更新。
- `validation_seconds`：一个验证工作单元，包含函数调用返回。
- `validation_queue_seconds`：冻结模型和少量数据、建立任务。
- `switch_seconds`：圈边界处理模型切换。
- `console_seconds`：圈末文字输出，单独记录，类似 GUI 不计入控制算法时间。

`diagnose_timing_v8` 显示总耗时最大的 10 步，另列 `other_learning_ms`，反映未被上述子项单独覆盖的学习计算时间。子项可能有微小计时误差。

被控对象仿真、图形、控制台输出仍计入 `loop_seconds`。同步 GUI/打印仍可能影响真实调度，实车不能直接使用此仿真主循环作为硬实时任务。

## 验收要求没有放宽

100 ms 上限不变；任何一次正式控制总计算超过它，`deadline_misses` 增加，`sampled_acceptance_pass=false`。当前预留 10 ms 余量以判断是否开始可选学习工作，不强行耗尽预算。

默认 70 ms 搜索预算、每周期 20 ms 学习软预算、5 ms 验证单元预算。计时检查不能抢占 MATLAB 函数或操作系统暂停；若仍发生尖峰，分项日志用于下一步定位，不能用平均值掩盖。

其他验收条件仍是完成请求圈数、零检测越界、最小车身角点道路余量 ≥0.4 m、状态有限、实际采样运行范围违反为零。

关注 summary：

- `control_max_ms / deadline_misses`
- `learning_max_ms / observation_max_ms / rls_max_ms`
- `validation_chunk_max_ms / validation_queue_max_ms / model_switch_max_ms`
- `validation_deferred_steps / validation_budget_aborts / rls_skipped_steps`
- `model_promotions / model_rollbacks / model_active_fraction`
- `slowest_step / slowest_decision_ms / slowest_learning_ms`

## 保存与其他边界

结果保存为 `results/v8_learn_candidate_<时间戳>.mat`，另有各圈 CSV。`learning_history.accepted` 表示验证通过，`learning_history.promoted` 才表示后来实际在圈边界切换；两者不可混淆。

每次运行从名义模型重新开始。当前没有跨运行自动恢复未完成验证任务。RLS 为固定 15 维特征、3 输出残差学习，不是 GP 或强化学习。

道路检查仍依赖原有假设车身尺寸（半宽 0.8 m、质心前后各 1.8 m），使用角点而非完整连续碰撞几何。原速度上限 5 m/s、转向 ±30°、0.15 s 控制周期与积分子步保持不变。

车辆与学习数学细节可参阅 `V7_BACKGROUND_CN.md`，但以本说明的调度与计时规则为准。验证结果见 `VALIDATION_CN.md`。
