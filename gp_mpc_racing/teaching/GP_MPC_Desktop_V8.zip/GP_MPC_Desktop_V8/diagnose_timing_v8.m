function T=diagnose_timing_v8(input)
% Accept an out struct or a V7/V8 MAT filename. Does not change source data.
if ischar(input) || isstring(input)
    data=load(input,'out');out=data.out;
else
    out=input;
end
ids=find(isfinite(out.control_seconds));
[~,order]=sort(out.control_seconds(ids),'descend');
ids=ids(order(1:min(10,numel(order))));
step=ids(:);simulation_s=reshape(out.t(ids),[],1);
names={'control_seconds','decision_seconds','learning_seconds','observation_seconds', ...
    'rls_seconds','validation_seconds','validation_queue_seconds','switch_seconds'};
A=NaN(numel(ids),numel(names));
for j=1:numel(names)
    if isfield(out,names{j}),A(:,j)=1000*reshape(out.(names{j})(ids),[],1);end
end
unattributed_learning_ms=A(:,3)-sum(A(:,4:8),2);
T=table(step,simulation_s,A(:,1),A(:,2),A(:,3),A(:,4),A(:,5),A(:,6),A(:,7),A(:,8), ...
    unattributed_learning_ms,'VariableNames',{'step','simulation_s','total_ms','decision_ms', ...
    'learning_ms','observation_ms','rls_ms','validation_ms','queue_ms','switch_ms','other_learning_ms'});
disp(T);
fprintf('Missing V7 component timings are NaN. Startup, plant simulation and GUI are separate.\n');
end
