function [bad,metrics]=v8_stability(X,U,clearance,c)
% Heuristic operating envelope, not a proof of tyre adhesion or stability.
beta=atan2(X(5,:),X(4,:));
front=atan2(X(5,:)+0.9*X(6,:),X(4,:))-U(1,:);
rear=atan2(X(5,:)-1.5*X(6,:),X(4,:));
betaLimit=c.betaHighSpeed+(c.betaLowSpeed-c.betaHighSpeed)* ...
    (1-min(max(X(4,:),0)/c.betaTransitionSpeed,1));
yawProxy=abs(X(4,:).*X(6,:));
bad=[~all(isfinite(X),1);X(4,:)<=0.5;abs(beta)>=betaLimit; ...
    abs(front)>=c.tireSlipMax;abs(rear)>=c.tireSlipMax; ...
    yawProxy>=c.yawAccelProxyMax;clearance<c.edgeMargin];
metrics=[beta;front;rear;yawProxy];
end
