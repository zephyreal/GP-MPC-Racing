function report=v8_warmup(x,last,m,c)
% Isolated synthetic data exercises empty/active model, RLS and both validator phases.
% No synthetic data or fitted model is returned to the live learner.
bootClock=tic;model=[];
for j=1:120,model=v8_rls(model,x,last,zeros(3,1),c);end
for j=1:2
    v8_control(x,last,m,c,[]);v8_control(x,last,m,c,model);
    v8_correction(model,repmat(x,1,16),repmat(last,1,16));
end
fake=struct('x',repmat(x,1,41),'u',repmat(last,1,40),'residual',zeros(40,3));
warmCfg=c;warmCfg.validationStepBudget=inf; % startup only; timing reported separately
job=v8_validation_begin(model,[],fake,1:40,warmCfg,0,0);
for j=1:200
    if job.phase==3,break;end
    job=v8_validation_tick(job,m,warmCfg);
end
assert(job.phase==3 && job.rollStep==c.horizon,'Warm-up did not exercise complete validation path.');
report=struct('seconds',toc(bootClock),'validation_calls',job.calls, ...
    'validation_max_chunk_ms',1000*job.maxChunkSeconds,'live_samples_used',0);
end
