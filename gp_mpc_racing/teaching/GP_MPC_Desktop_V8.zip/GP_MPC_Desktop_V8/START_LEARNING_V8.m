% Odd laps train; even laps queue validation. Process one chunk each later control step.
root=fileparts(mfilename('fullpath'));addpath(root,'-begin');
out=run_stable_v8(struct('laps',6,'learn',true,'live',true));

diagnose_timing_v8(out);
