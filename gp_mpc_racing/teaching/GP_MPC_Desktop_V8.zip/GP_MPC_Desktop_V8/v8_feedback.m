function [U,vref]=v8_feedback(X,last,m,c,offset,speedScale,lookScale)
[s,e]=v8_project(m,X);
look=(1.8+0.35*max(X(4,:),0)).*lookScale;
[target,~]=v8_reference(m,s+look);[~,vref]=v8_reference(m,s);
alpha=atan2(target(2,:)-X(2,:),target(1,:)-X(1,:))-X(3,:);
distance=max(0.5,sqrt(sum((target-X(1:2,:)).^2,1)));
delta=atan(2*2.4*sin(alpha)./distance)+offset;
delta=max(-c.steerMax,min(c.steerMax,delta));
delta=max(last(1,:)-c.steerRate*c.dt,min(last(1,:)+c.steerRate*c.dt,delta));
vref=vref.*speedScale;
% Reduce speed when deviation / sideslip increases; no progress reward.
vref=vref./(1+0.5*abs(e)+2*abs(atan2(X(5,:),X(4,:))));
a=max(-c.brakeAccel,min(c.accelMax,1.5*(vref-X(4,:))));
% Nominal force mapping; true model mass differs as in previous versions.
T=750*a./(4000*(a>=0)+8000*(a<0));
U=[delta;T;max(0,X(4,:))];
end
