import validate_v7_python as v
import numpy as np
from copy import deepcopy
base_step=v.step
active=None

def features(X,U):
 z=np.vstack([X[3:6],U[:2]])/np.array([5,.6,.5,np.pi/6,.3])[:,None]
 return np.vstack([np.ones(z.shape[1]),z,z*z,z[0]*z[3],z[1]*z[2],z[3]*z[4],z[0]*z[4]]),z

def update(model,X,U,target):
 if model is None:model={'W':np.zeros((3,15)),'P':100*np.eye(15),'count':0,'lo':np.full((5,1),np.inf),'hi':np.full((5,1),-np.inf)}
 p,z=features(X,U);P=model['P'];g=P@p/(.9995+(p.T@P@p).item());model['W']+=(target-model['W']@p)@g.T;P=(P-g@(p.T@P))/.9995;model['P']=(P+P.T)/2;model['count']+=1;model['lo']=np.minimum(model['lo'],z);model['hi']=np.maximum(model['hi'],z);return model

def correction(model,X,U):
 if model is None or model['count']<100:return np.zeros((3,X.shape[1]))
 p,z=features(X,U);supported=np.all((z>=model['lo']-.1)&(z<=model['hi']+.1),axis=0);conf=1/(1+np.maximum(0,np.sum(p*(model['P']@p),axis=0)));bound=np.array([.2,.08,.08])[:,None];return .3*np.clip(model['W']@p,-bound,bound)*conf*supported

def predict(X,U,model):
 Y=base_step(X,U,False);Y[3:6]+=correction(model,X,U);return Y

def step(X,U,truth):return base_step(X,U,True) if truth else predict(X,U,active)
v.step=step

def bad(X,U):
 beta=np.arctan2(X[4],X[3]);af=np.arctan2(X[4]+.9*X[5],X[3])-U[0];ar=np.arctan2(X[4]-1.5*X[5],X[3]);bl=.3+.2*(1-np.minimum(np.maximum(X[3],0)/5,1))
 return (~np.all(np.isfinite(X),axis=0))|(X[3]<=.5)|(abs(beta)>=bl)|(abs(af)>=.2)|(abs(ar)>=.2)|(abs(X[3]*X[5])>=4)|(v.clearance(X)<.4)

def validate(candidate,current,xs,us,ys):
 xs=np.concatenate(xs,axis=1);us=np.concatenate(us,axis=1);ys=np.concatenate(ys,axis=1);n=us.shape[1]
 ids=np.floor(np.linspace(0,n-1,min(160,n))+.5).astype(int);X=xs[:,ids];U=us[:,ids];Y=ys[:,ids];a=np.mean((Y-correction(current,X,U))**2,axis=1);b=np.mean((Y-correction(candidate,X,U))**2,axis=1);scale=np.array([.05,.02,.02])**2
 if np.any(b>1.05*a+1e-8) or np.mean(b/scale)>.95*np.mean(a/scale):return False,('one-step',np.round(b/a,3))
 starts=np.floor(np.linspace(0,n-12,3)+.5).astype(int);ox=xs[:,starts].copy();nx=ox.copy();ae=be=0;scale6=np.array([.5,.5,.2,.5,.2,.2])[:,None]
 for j in range(12):
  U=us[:,starts+j];ox=predict(ox,U,current);nx=predict(nx,U,candidate);actual=xs[:6,starts+j+1];ae+=np.sum(((ox[:6]-actual)/scale6)**2);be+=np.sum(((nx[:6]-actual)/scale6)**2)
  if np.any(bad(nx,U)):return False,('envelope',)
 return be<=1.05*ae+1e-6,('ratios',np.round(b/a,3),be/ae)

if __name__=='__main__':
 x=np.array([[5,0,0,3,0,0,0.]]).T;last=np.zeros((3,1));old=v.project(x)[0][0];progress=0;candidate=None;lap=1;start=0;mincl=99;maxe=0;fallbacks=0;rollbacks=0;promotions=0;used=0;badRun=0;lapRollback=False;actual_bad_count=0;xs=[x.copy()];us=[];ys=[];errors=[]
 for k in range(10000):
  was_active=active is not None;used+=was_active;u,fb=v.control(x,last);fallbacks+=fb
  nxt=x.copy();cl=99
  for j in range(10):
   nxt=nxt+.015*v.f(nxt+.0075*v.f(nxt,u,True),u,True);cl=min(cl,v.clearance(nxt)[0])
  actual_bad=bool(np.any(bad(nxt,u)));actual_bad_count+=actual_bad
  nominal=base_step(x,u,False);target=nxt[3:6]-nominal[3:6];d=correction(active,x,u);errors.append((nxt-nominal).ravel());us.append(u.copy());ys.append(target.copy());xs.append(nxt.copy())
  if active is not None:
   be=np.linalg.norm(target/np.array([.05,.02,.02])[:,None]);ce=np.linalg.norm((target-d)/np.array([.05,.02,.02])[:,None]);badRun=badRun+1 if ce>1.5*be+.05 else 0
   if cl<.6 or actual_bad or badRun>=3:active=None;badRun=0;rollbacks+=1;lapRollback=True
  if lap%2==1 and cl>=.4 and not actual_bad:candidate=update(candidate,x,u,target)
  ss,e=v.project(nxt);progress+=(ss[0]-old+v.L/2)%v.L-v.L/2;old=ss[0];mincl=min(mincl,cl);maxe=max(maxe,abs(e[0]));x=nxt;last=u
  assert np.all(np.isfinite(x)) and x[3,0]>0 and cl>=0,('failed',k,cl)
  if progress>=lap*v.L:
   status='training'
   if lap%2==0 and not lapRollback:
    passed,status=validate(candidate,active,xs,us,ys)
    if passed:active=deepcopy(candidate);promotions+=1;badRun=0
   print('lap',lap,'steps',k+1,'minclear',round(mincl,4),'fallback',fallbacks,'active',active is not None,'rollback',rollbacks,'validation',status,flush=True)
   lap+=1;xs=[x.copy()];us=[];ys=[];lapRollback=False
   if lap>6:break
 print(dict(steps=k+1,laps=lap-1,min_clearance=mincl,max_error=maxe,fallbacks=fallbacks,promotions=promotions,rollbacks=rollbacks,model_used_steps=used,actual_envelope_violations=actual_bad_count),flush=True)
