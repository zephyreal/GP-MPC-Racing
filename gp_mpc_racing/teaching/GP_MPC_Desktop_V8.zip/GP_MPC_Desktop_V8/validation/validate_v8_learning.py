import validate_v7_learning as lib
from copy import deepcopy
import numpy as np
v=lib.v
class Job:
 def __init__(self,model,active,xs,us,ys,revision):
  self.model=deepcopy(model);self.active=deepcopy(active);self.revision=revision
  xs=np.concatenate(xs,axis=1);us=np.concatenate(us,axis=1);ys=np.concatenate(ys,axis=1);n=us.shape[1]
  ids=np.floor(np.linspace(0,n-1,min(160,n))+.5).astype(int)
  self.X,self.U,self.Y=xs[:,ids],us[:,ids],ys[:,ids]
  starts=np.floor(np.linspace(0,n-12,3)+.5).astype(int)
  self.ox=xs[:,starts].copy();self.nx=self.ox.copy()
  self.rollU=[us[:,starts+j] for j in range(12)];self.actual=[xs[:6,starts+j+1] for j in range(12)]
  self.phase=1;self.cursor=0;self.j=0;self.a=np.zeros(3);self.b=np.zeros(3);self.ae=self.be=0;self.calls=0;self.accepted=False
 def tick(self):
  assert self.phase!=3
  self.calls+=1
  if self.phase==1:
   ids=slice(self.cursor,min(self.cursor+16,self.X.shape[1]));X,U,Y=self.X[:,ids],self.U[:,ids],self.Y[:,ids]
   self.a+=np.sum((Y-lib.correction(self.active,X,U))**2,axis=1);self.b+=np.sum((Y-lib.correction(self.model,X,U))**2,axis=1);self.cursor=min(self.cursor+16,self.X.shape[1])
   if self.cursor==self.X.shape[1]:
    a,b=self.a/self.cursor,self.b/self.cursor;scale=np.array([.05,.02,.02])**2
    self.phase=3 if np.any(b>1.05*a+1e-8) or np.mean(b/scale)>.95*np.mean(a/scale) else 2
  else:
   U=self.rollU[self.j];self.ox=lib.predict(self.ox,U,self.active);self.nx=lib.predict(self.nx,U,self.model);scale=np.array([.5,.5,.2,.5,.2,.2])[:,None]
   self.ae+=np.sum(((self.ox[:6]-self.actual[self.j])/scale)**2);self.be+=np.sum(((self.nx[:6]-self.actual[self.j])/scale)**2);self.j+=1
   if np.any(lib.bad(self.nx,U)):self.phase=3
   elif self.j==12:self.phase=3;self.accepted=self.be<=1.05*self.ae+1e-6
if __name__=='__main__':
 x=np.array([[5,0,0,3,0,0,0.]]).T;last=np.zeros((3,1));old=v.project(x)[0][0];progress=0;candidate=active=job=ready=None;revision=0;lap=1;badRun=0;lapRollback=False
 xs=[x.copy()];us=[];ys=[];mincl=99;fallbacks=used=promotions=rollbacks=violations=deferred=0;events=[]
 for k in range(10000):
  lib.active=active;used+=active is not None;u,fb=v.control(x,last);fallbacks+=fb;nxt=x.copy();cl=99
  for j in range(10):
   nxt+=.015*v.f(nxt+.0075*v.f(nxt,u,True),u,True);cl=min(cl,v.clearance(nxt)[0])
  actual_bad=bool(np.any(lib.bad(nxt,u)));violations+=actual_bad
  nominal=lib.base_step(x,u,False);target=nxt[3:6]-nominal[3:6];d=lib.correction(active,x,u)
  us.append(u.copy());ys.append(target.copy());xs.append(nxt.copy())
  if active is not None:
   be=np.linalg.norm(target/np.array([.05,.02,.02])[:,None]);ce=np.linalg.norm((target-d)/np.array([.05,.02,.02])[:,None]);badRun=badRun+1 if ce>1.5*be+.05 else 0
   if cl<.6 or actual_bad or badRun>=3:active=None;revision+=1;ready=None;badRun=0;rollbacks+=1;lapRollback=True
  if lap%2==1 and cl>=.4 and not actual_bad:candidate=lib.update(candidate,x,u,target)
  if job is not None:
   if job.revision!=revision or cl<.6 or actual_bad:job.phase=3;job.accepted=False
   elif k%7!=0:job.tick()
   else:deferred+=1
   if job.phase==3:
    assert job.calls<=22
    events.append((k+1,job.accepted,job.calls))
    if job.accepted:ready=(deepcopy(job.model),revision)
    job=None
  ss,e=v.project(nxt);progress+=(ss[0]-old+v.L/2)%v.L-v.L/2;old=ss[0];mincl=min(mincl,cl);x=nxt;last=u
  assert np.all(np.isfinite(x)) and x[3,0]>0 and cl>=0
  if progress>=lap*v.L:
   promoted=False
   if ready is not None:
    if ready[1]==revision and not lapRollback:active=ready[0];revision+=1;badRun=0;promotions+=1;promoted=True
    ready=None
   if not promoted and lap%2==0 and lap<6 and not lapRollback and job is None:
    job=Job(candidate,active,xs,us,ys,revision)
    # Mathematical parity on the very same frozen data, without time limits.
    parity=deepcopy(job)
    while parity.phase!=3:parity.tick()
    batch_pass,_=lib.validate(candidate,active,xs,us,ys)
    assert parity.accepted==batch_pass
   print('lap',lap,'steps',k+1,'clearance',round(mincl,4),'fallback',fallbacks,'active',active is not None,'promoted',promoted,flush=True)
   lap+=1;xs=[x.copy()];us=[];ys=[];lapRollback=False
   if lap>6:break
 print(dict(steps=k+1,laps=6,min_clearance=mincl,fallbacks=fallbacks,promotions=promotions,rollbacks=rollbacks,model_used_steps=used,actual_envelope_violations=violations,deferred_validation_steps=deferred,validation_events=events),flush=True)
