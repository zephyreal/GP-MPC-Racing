from pathlib import Path
import numpy as np
from scipy.io import loadmat
from time import perf_counter
P=loadmat(Path(__file__).resolve().parents[1]/'track_fullsize.mat')['track_c'][:,:-1]; D=np.roll(P,-1,axis=1)-P; le=np.linalg.norm(D,axis=0); s=np.r_[0,np.cumsum(le[:-1])]; L=sum(le); hd=np.arctan2(D[1],D[0]); cur=np.angle(np.exp(1j*(np.roll(hd,-1)-hd)))/np.maximum(.1,(le+np.roll(le,-1))/2); speed=np.maximum(2.5,np.minimum(5,np.sqrt(2/np.maximum(abs(cur),1e-4))))
for _ in range(3):
 for i in range(len(s)-1,-1,-1): speed[i]=min(speed[i],np.sqrt(speed[(i+1)%len(s)]**2+4*le[i]))
def project(X,distance=False):
 dx=X[0]-P[0,:,None];dy=X[1]-P[1,:,None];a=np.clip((dx*D[0,:,None]+dy*D[1,:,None])/le[:,None]**2,0,1);rx=dx-a*D[0,:,None];ry=dy-a*D[1,:,None];idx=np.argmin(rx**2+ry**2,axis=0);q=np.arange(X.shape[1]);return s[idx]+a[idx,q]*le[idx], (np.sqrt(rx[idx,q]**2+ry[idx,q]**2) if distance else -np.sin(hd[idx])*rx[idx,q]+np.cos(hd[idx])*ry[idx,q])
def ref(z):
 z=z%L;return np.array([np.interp(z,np.r_[s,L],np.r_[p,p[0]]) for p in P]),np.interp(z,np.r_[s,L],np.r_[speed,speed[0]])
def feedback(X,last,o=0,sc=1,ls=1):
 ss,e=project(X);target,_=ref(ss+(1.8+.35*np.maximum(X[3],0))*ls);_,vr=ref(ss);alpha=np.arctan2(target[1]-X[1],target[0]-X[0])-X[2];dist=np.maximum(.5,np.linalg.norm(target-X[:2],axis=0));delta=np.clip(np.arctan(4.8*np.sin(alpha)/dist)+o,-np.pi/6,np.pi/6);delta=np.clip(delta,last[0]-np.pi/3*.15,last[0]+np.pi/3*.15);vr=vr*sc/(1+.5*abs(e)+2*abs(np.arctan2(X[4],X[3])));a=np.clip(1.5*(vr-X[3]),-2,1.2);return np.array([delta,750*a/np.where(a>=0,4000,8000),np.maximum(0,X[3])]),vr
def f(X,U,truth):
 vx,vy,r,psi=X[3],X[4],X[5],X[2];delta,T=np.clip(U[0],-np.pi/6,np.pi/6),np.clip(U[1],-1,1);ar=np.arctan2(vy-1.5*r,vx);af=np.arctan2(vy+.9*r,vx)-delta;F=T*(4000*(T>0)+8000*(T<0)*np.sign(vx))
 if truth:M,I=500,600;yr=-4000*np.sin(8*np.arctan(.45*ar+.5*(.45*ar-np.arctan(.45*ar))));yf=-4560.4*np.sin(8*np.arctan(.4*af+.5*(.4*af-np.arctan(.4*af))))
 else:M,I=750,900;yr,yf=-35000*ar,-35000*af
 cd,sd=np.cos(delta),np.sin(delta)
 return np.array([vx*np.cos(psi)-vy*np.sin(psi),vx*np.sin(psi)+vy*np.cos(psi),r,(.5*F+.5*F*cd-yf*sd+vy*r)/M,(yr+.5*F*sd+yf*cd-vy*r)/M,(.9*yf*cd+.45*F*sd-1.5*yr)/I,U[2]])
def step(X,U,truth):
 for _ in range(10):X=X+.015*f(X+.0075*f(X,U,truth),U,truth)
 return X
def clearance(X):
 out=np.full(X.shape[1],np.inf)
 for a in [1.8,-1.8]:
  for b in [.8,-.8]:
   Q=np.array([X[0]+a*np.cos(X[2])-b*np.sin(X[2]),X[1]+a*np.sin(X[2])+b*np.cos(X[2])]);_,e=project(Q,True);out=np.minimum(out,3-abs(e))
 return out
O,V,H=np.meshgrid([-.05,0,.05],[.65,.85,1],[1,1.35],indexing='ij');O,V,H=O.ravel(order='F'),V.ravel(order='F'),H.ravel(order='F')
def control(x,last):
 X=np.repeat(x,18,axis=1);prev=np.repeat(last,18,axis=1);cost=np.zeros(18);ok=np.ones(18,dtype=bool)
 for k in range(12):
  U,vr=feedback(X,prev,O,V,H)
  if k==0:first=U.copy()
  X=step(X,U,False);cl=clearance(X);_,e=project(X);beta=np.arctan2(X[4],X[3]);af=np.arctan2(X[4]+.9*X[5],X[3])-U[0];ar=np.arctan2(X[4]-1.5*X[5],X[3]);bl=.3+.2*(1-np.minimum(np.maximum(X[3],0)/5,1));ok&=np.all(np.isfinite(X),axis=0)&(X[3]>.5)&(abs(beta)<bl)&(abs(af)<.20)&(abs(ar)<.20)&(abs(X[3]*X[5])<4)&(cl>=.4);cost+=8*e**2+.8*(X[3]-vr)**2+2*beta**2+.5*(U[0]-prev[0])**2+.2*(5-X[3])**2;prev=U
 cost[~ok]=np.inf;j=np.argmin(cost)
 return (first[:,j:j+1],False) if np.isfinite(cost[j]) else (feedback(x,last,sc=.55)[0],True)
if __name__=='__main__':
 import sys
 mode=sys.argv[1] if len(sys.argv)>1 else 'backup';laps=int(sys.argv[2]) if len(sys.argv)>2 else 2
 x=np.array([[5,0,0,3,0,0,0.]]).T;last=np.zeros((3,1));old=project(x)[0][0];progress=0;mincl=99;maxe=0;falls=0;t=perf_counter()
 for k in range(10000):
  if mode=='candidate':u,fb=control(x,last);falls+=fb
  else:u=feedback(x,last,sc=.55 if mode=='backup' else 1)[0]
  x=step(x,u,True);ss,e=project(x);progress+=(ss[0]-old+L/2)%L-L/2;old=ss[0];last=u;cl=clearance(x)[0];mincl=min(mincl,cl);maxe=max(maxe,abs(e[0]))
  if cl<0 or not np.all(np.isfinite(x)) or x[3,0]<0:print('FAIL',k,x.ravel(),cl,flush=True);break
  if (k+1)%200==0:print(mode,k+1,round(progress/L,3),round(mincl,3),'fallback',falls,flush=True)
  if progress>=laps*L:break
 print(dict(mode=mode,steps=k+1,laps=progress/L,min_clearance=mincl,max_error=maxe,fallback=falls,wall=perf_counter()-t),flush=True)
