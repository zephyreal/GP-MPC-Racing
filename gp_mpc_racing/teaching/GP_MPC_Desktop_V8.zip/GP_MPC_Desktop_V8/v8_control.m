function [u,pred,info]=v8_control(x,last,m,c,active)
if nargin<5,active=[];end
searchClock=tic;
% Always compute a cheap backup first; it is not a certified safe controller.
[uBackup,~]=v8_feedback(x,last,m,c,0,0.55,1);
info=struct('fallback',true,'feasible',false,'timedOut',false,'candidates',0, ...
    'predictedClearance',NaN,'seconds',0,'feasibleCount',0, ...
    'rejectCounts',zeros(7,1),'rejectMask',zeros(18,1,'uint16'),'screenComplete',false);
pred=x;u=uBackup;
if strcmp(c.controller,'backup'),info.seconds=toc(searchClock);return;end
% 18 fixed feedback policies; no fmincon and no gradient estimation.
[o,v,l]=ndgrid([-0.05 0 0.05],[0.65 0.85 1],[1 1.35]);
o=o(:)';v=v(:)';l=l(:)';B=numel(o);
X=repmat(x,1,B);lastU=repmat(last,1,B);
paths=zeros(7,c.horizon+1,B);paths(:,1,:)=reshape(X,7,1,B);
first=zeros(3,B);cost=zeros(1,B);ok=true(1,B);clearMin=inf(1,B);rejected=false(7,B);
for k=1:c.horizon
    if toc(searchClock)>c.searchBudget
        info.timedOut=true;info.seconds=toc(searchClock);return;
    end
    [U,vr]=v8_feedback(X,lastU,m,c,o,v,l);
    if k==1,first=U;end
    X=v8_predict(X,U,c,active);
    [clearance,e]=v8_clearance(m,X,c);
    beta=atan2(X(5,:),X(4,:));
    bad=v8_stability(X,U,clearance,c);rejected=rejected | bad;
    ok=~any(rejected,1);
    info.rejectCounts=sum(rejected,2);
    info.rejectMask=uint16(sum(double(rejected).*(2.^(0:6)'),1))';
    clearMin=min(clearMin,clearance);
    cost=cost+8*e.^2+0.8*(X(4,:)-vr).^2+2*beta.^2+ ...
        0.5*(U(1,:)-lastU(1,:)).^2+0.2*(c.speedMax-X(4,:)).^2;
    paths(:,k+1,:)=reshape(X,7,1,B);lastU=U;
end
info.candidates=B;info.screenComplete=true;info.feasibleCount=sum(ok);
if toc(searchClock)>c.searchBudget
    info.timedOut=true;
else
    cost(~ok)=inf;[best,j]=min(cost);
    if isfinite(best)
        u=first(:,j);pred=paths(:,:,j);info.fallback=false;info.feasible=true;
        info.predictedClearance=clearMin(j);
    end
end
info.seconds=toc(searchClock);
end
