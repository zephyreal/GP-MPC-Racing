function d=v8_correction(model,X,U)
d=zeros(3,size(X,2));
if isempty(model) || model.count<100,return;end
[p,z]=v8_features(X,U);
supported=all(z>=model.lo-0.10 & z<=model.hi+0.10,1);
% P is an RLS information inverse, not a calibrated probabilistic guarantee.
confidence=1./(1+max(0,sum(p.*(model.P*p),1)));
bound=[0.20;0.08;0.08];raw=model.W*p;
d=model.gain*max(-bound,min(bound,raw)).*confidence.*supported;
d(:,~all(isfinite(d),1))=0;
end
