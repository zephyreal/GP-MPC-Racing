function X=v8_step(X,U,dt,kind,hmax)
% Batched original full-size equations; deterministic midpoint integration.
% Physical formulae, including original Coriolis terms, are unchanged.
n=ceil(dt/hmax);h=dt/n;
for j=1:n
    k=f(X,U,kind);X=X+h*f(X+0.5*h*k,U,kind);
end
end
function d=f(X,U,kind)
vx=X(4,:);vy=X(5,:);r=X(6,:);psi=X(3,:);
delta=max(-pi/6,min(pi/6,U(1,:)));T=max(-1,min(1,U(2,:)));
ar=atan2(vy-1.5*r,vx);af=atan2(vy+0.9*r,vx)-delta;
F=T.*(4000*(T>0)+8000*(T<0).*sign(vx));
if strcmp(kind,'true')
    M=500;I=600;
    yr=-4000*sin(8*atan(0.45*ar+0.5*(0.45*ar-atan(0.45*ar))));
    yf=-4560.4*sin(8*atan(0.4*af+0.5*(0.4*af-atan(0.4*af))));
else
    M=750;I=900;yr=-35000*ar;yf=-35000*af;
end
cosDelta=cos(delta);sd=sin(delta);
d=[vx.*cos(psi)-vy.*sin(psi);vx.*sin(psi)+vy.*cos(psi);r; ...
    (0.5*F+0.5*F.*cosDelta-yf.*sd+vy.*r)/M; ...
    (yr+0.5*F.*sd+yf.*cosDelta-vy.*r)/M; ...
    (0.9*yf.*cosDelta+0.45*F.*sd-1.5*yr)/I;U(3,:)];
end
