% Full multi-lap benchmark; GUI disabled, physics/geometry checks still run.
root=fileparts(mfilename('fullpath'));addpath(root,'-begin');
bench=run_stable_v8(struct('laps',10,'live',false));
