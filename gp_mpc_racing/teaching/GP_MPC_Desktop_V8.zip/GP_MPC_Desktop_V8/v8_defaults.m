function c=v8_defaults(user)
% Current full-size model; dimensions below are explicit footprint assumptions.
c=struct('laps',5,'dt',0.15,'maxSimTime',600,'live',true,'drawEvery',2, ...
    'speedMax',5,'speedMin',2.5,'initialSpeed',3,'lateralAccel',2, ...
    'brakeAccel',2,'accelMax',1.2,'steerMax',pi/6,'steerRate',pi/3, ...
    'halfWidth',0.8,'frontExtent',1.8,'rearExtent',1.8,'edgeMargin',0.4, ...
    'horizon',12,'integrationStep',0.015,'searchBudget',0.070,'deadline',0.100, ...
    'saveResults',true,'stopOnViolation',true,'controller','candidate', ...
    'learn',true,'rl',false,'learningGain',0.3,'learningBudget',0.020,'validationChunk',16,'validationStepBudget',0.005, ...
    'deadlineReserve',0.010, ...
    'rlsForgetting',0.9995,'tireSlipMax',0.20,'yawAccelProxyMax',4, ...
    'betaLowSpeed',0.50,'betaHighSpeed',0.30,'betaTransitionSpeed',5);
if nargin>0
    names=fieldnames(user);
    for i=1:numel(names)
        assert(isfield(c,names{i}),'Unknown V8 option: %s',names{i});
        c.(names{i})=user.(names{i});
    end
end
if nargin<1 || ~isfield(user,'maxSimTime'),c.maxSimTime=max(600,150*c.laps);end
assert(~c.rl,'RL is not enabled in this version.');
assert(c.learningGain>0 && c.learningGain<=0.5 && c.learningBudget>0);
assert(c.searchBudget+c.learningBudget<c.deadline);
assert(c.validationChunk>=1 && c.validationChunk<=16 && mod(c.validationChunk,1)==0);
assert(c.validationStepBudget>0 && c.validationStepBudget<=0.010);
assert(c.deadlineReserve>0 && c.deadlineReserve<c.deadline);
assert(c.rlsForgetting>0.9 && c.rlsForgetting<=1);
assert(c.tireSlipMax>0 && c.tireSlipMax<pi/2 && c.yawAccelProxyMax>0);
assert(c.betaLowSpeed>=c.betaHighSpeed && c.betaHighSpeed>0 && c.betaTransitionSpeed>0);
assert(c.dt>0 && c.horizon>=1 && mod(c.horizon,1)==0);
assert(c.laps>=1 && mod(c.laps,1)==0 && c.maxSimTime>=c.dt);
assert(c.speedMin>0 && c.speedMax>=c.speedMin && c.initialSpeed>0);
assert(c.integrationStep>0 && c.integrationStep<=0.02);
assert(c.searchBudget>0 && c.searchBudget<c.deadline && c.deadline<=0.100);
assert(c.steerMax>0 && c.steerMax<=pi/6 && c.steerRate>0);
assert(c.halfWidth>0 && c.frontExtent>0 && c.rearExtent>0 && c.edgeMargin>=0);
assert(c.drawEvery>=1 && mod(c.drawEvery,1)==0);
assert(c.lateralAccel>0 && c.brakeAccel>0 && c.accelMax>0);
assert(any(strcmp(c.controller,{'candidate','backup'})));
end

