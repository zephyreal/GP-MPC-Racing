function m=v8_map(c)
f=load(fullfile(fileparts(mfilename('fullpath')),'track_fullsize.mat'));
m=f;P=f.track_c;
% Remove near-duplicate closing point and close with a real segment.
if norm(P(:,end)-P(:,1))<0.05,P=P(:,1:end-1);end
m.P=P;m.D=P(:,[2:end 1])-P;m.len=sqrt(sum(m.D.^2,1));
m.s=[0 cumsum(m.len(1:end-1))];m.L=sum(m.len);m.width=6;
m.heading=atan2(m.D(2,:),m.D(1,:));
dpsi=atan2(sin(m.heading([2:end 1])-m.heading),cos(m.heading([2:end 1])-m.heading));
m.curvature=dpsi./max(0.1,(m.len+m.len([2:end 1]))/2);
v=min(c.speedMax,sqrt(c.lateralAccel./max(abs(m.curvature),1e-4)));
v=max(c.speedMin,v);
% Circular backward braking pass; no online optimisation for speed planning.
for pass=1:3
    for i=numel(v):-1:1
        j=mod(i,numel(v))+1;v(i)=min(v(i),sqrt(v(j)^2+2*c.brakeAccel*m.len(i)));
    end
end
m.v=v;
assert(c.halfWidth+c.edgeMargin<m.width/2,'Footprint does not fit in road.');
end
