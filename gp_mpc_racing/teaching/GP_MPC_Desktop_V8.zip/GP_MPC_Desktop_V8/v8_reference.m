function [p,v]=v8_reference(m,s)
s=mod(s,m.L);
p=interp1([m.s m.L]',[m.P m.P(:,1)]',s(:),'linear')';
v=interp1([m.s m.L]',[m.v m.v(1)]',s(:),'linear')';
end
