function job=v8_validation_tick(job,m,c)
% One call performs at most 16 one-step checks OR one batched rollout stage.
% No loop drains the full job inside a control cycle.
if job.phase==3,return;end
chunkClock=tic;
if job.phase==1
    ids=job.cursor:min(job.cursor+c.validationChunk-1,size(job.X,2));
    old=v8_correction(job.baseline,job.X(:,ids),job.U(:,ids));
    new=v8_correction(job.candidate,job.X(:,ids),job.U(:,ids));
    job.a=job.a+sum((job.Y(:,ids)-old).^2,2);
    job.b=job.b+sum((job.Y(:,ids)-new).^2,2);
    job.cursor=ids(end)+1;
    if job.cursor>size(job.X,2)
        a=job.a/size(job.X,2);b=job.b/size(job.X,2);scale=[0.05;0.02;0.02].^2;
        job.event.oldError=mean(a./scale);job.event.newError=mean(b./scale);
        if ~all(isfinite([a;b])) || any(b>1.05*a+1e-8) || job.event.newError>0.95*job.event.oldError
            job.phase=3;job.event.reason='Held-out one-step test failed';
        else
            job.phase=2;
        end
    end
elseif job.phase==2
    j=job.rollStep+1;U=job.rollU(:,:,j);
    job.oldX=v8_predict(job.oldX,U,c,job.baseline);
    job.newX=v8_predict(job.newX,U,c,job.candidate);
    scale6=[0.5;0.5;0.2;0.5;0.2;0.2];actual=job.actual(:,:,j);
    job.ae=job.ae+sum(sum(((job.oldX(1:6,:)-actual)./scale6).^2));
    job.be=job.be+sum(sum(((job.newX(1:6,:)-actual)./scale6).^2));
    clearance=v8_clearance(m,job.newX,c);bad=v8_stability(job.newX,U,clearance,c);
    job.rollStep=j;
    if any(bad(:))
        job.phase=3;job.event.reason='Held-input rollout left operating envelope';
    elseif j==c.horizon
        job.phase=3;job.event.oldRolloutError=job.ae;job.event.newRolloutError=job.be;
        if job.be>1.05*job.ae+1e-6
            job.event.reason='Held-input multistep prediction worsened';
        else
            job.event.accepted=true;job.event.reason='Passed incremental held-out tests';
        end
    end
end
elapsed=toc(chunkClock);job.calls=job.calls+1;
job.maxChunkSeconds=max(job.maxChunkSeconds,elapsed);job.event.seconds=job.event.seconds+elapsed;
if elapsed>c.validationStepBudget
    job.phase=3;job.event.accepted=false;job.event.reason='Validation chunk exceeded budget';
end
end
