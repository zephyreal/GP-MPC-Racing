function model=v8_rls(model,X,U,target,c)
% Fixed 15-feature, 3-output recursive least squares; constant memory.
if isempty(model)
    model=struct('W',zeros(3,15),'P',100*eye(15),'count',0, ...
        'lo',inf(5,1),'hi',-inf(5,1),'gain',c.learningGain);
end
[p,z]=v8_features(X,U);
if any(~isfinite([p;target])),return;end
P=model.P;g=P*p/(c.rlsForgetting+p'*P*p);
W=model.W+(target-model.W*p)*g';
P=(P-g*(p'*P))/c.rlsForgetting;P=(P+P')/2;
if any(~isfinite(W(:))) || any(~isfinite(P(:))),return;end
model.W=W;model.P=P;model.count=model.count+1;
model.lo=min(model.lo,z);model.hi=max(model.hi,z);
end
