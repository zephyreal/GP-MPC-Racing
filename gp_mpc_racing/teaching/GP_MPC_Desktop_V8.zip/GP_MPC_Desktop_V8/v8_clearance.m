function [clearance,e,s]=v8_clearance(m,X,c)
[s,e]=v8_project(m,X);
% Evaluate all four footprint corners against actual polyline, including curves.
clearance=inf(1,size(X,2));
for a=[c.frontExtent -c.rearExtent]
    for b=[c.halfWidth -c.halfWidth]
        corners=[X(1,:)+a*cos(X(3,:))-b*sin(X(3,:)); ...
                 X(2,:)+a*sin(X(3,:))+b*cos(X(3,:))];
        [~,~,~,~,distance]=v8_project(m,corners);
        clearance=min(clearance,m.width/2-distance);
    end
end
end
