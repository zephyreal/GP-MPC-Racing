% V8 with revised screening, without online model learning.
root=fileparts(mfilename('fullpath'));addpath(root,'-begin');
baseline=run_stable_v8(struct('laps',5,'learn',false,'live',true));
