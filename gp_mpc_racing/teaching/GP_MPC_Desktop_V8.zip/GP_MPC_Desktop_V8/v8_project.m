function [s,e,heading,idx,distance]=v8_project(m,X)
% Exact projection onto sampled centreline segments. All columns are candidates.
dx=X(1,:)-m.P(1,:)';dy=X(2,:)-m.P(2,:)';
a=max(0,min(1,(dx.*m.D(1,:)'+dy.*m.D(2,:)')./(m.len'.^2)));
rx=dx-a.*m.D(1,:)';ry=dy-a.*m.D(2,:)';
[~,idx]=min(rx.^2+ry.^2,[],1);
q=sub2ind(size(a),idx,1:size(X,2));
s=m.s(idx)+a(q).*m.len(idx);heading=m.heading(idx);
distance=sqrt(rx(q).^2+ry(q).^2);
e=-sin(heading).*rx(q)+cos(heading).*ry(q);
end
