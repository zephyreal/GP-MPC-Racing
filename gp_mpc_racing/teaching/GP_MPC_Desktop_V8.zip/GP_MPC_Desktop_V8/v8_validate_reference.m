function event=v8_validate_reference(candidate,active,out,span,m,c)
% Candidate trained on preceding odd laps; current even lap is fully held out.
checkClock=tic;
event=struct('accepted',false,'reason','Not enough data','oldError',NaN, ...
    'newError',NaN,'oldRolloutError',NaN,'newRolloutError',NaN,'seconds',0);
if isempty(candidate) || candidate.count<100 || numel(span)<40
    event.seconds=toc(checkClock);return;
end
ids=span(unique(round(linspace(1,numel(span),min(160,numel(span))))));
X=out.x(:,ids);U=out.u(:,ids);Y=out.residual(ids,:)';
old=v8_correction(active,X,U);new=v8_correction(candidate,X,U);
a=mean((Y-old).^2,2);b=mean((Y-new).^2,2);scale=[0.05;0.02;0.02].^2;
event.oldError=mean(a./scale);event.newError=mean(b./scale);
if ~all(isfinite([a;b])) || any(b>1.05*a+1e-8) || event.newError>0.95*event.oldError
    event.reason='Held-out one-step test failed';event.seconds=toc(checkClock);return;
end
N=c.horizon;
starts=span(unique(round(linspace(1,numel(span)-N+1,3))));
oldX=out.x(:,starts);newX=oldX;ae=0;be=0;
for j=1:N
    if toc(checkClock)>c.learningBudget
        event.reason='Validation budget exceeded';event.seconds=toc(checkClock);return;
    end
    U=out.u(:,starts+j-1);oldX=v8_predict(oldX,U,c,active);newX=v8_predict(newX,U,c,candidate);
    actual=out.x(1:6,starts+j);scale6=[0.5;0.5;0.2;0.5;0.2;0.2];
    ae=ae+sum(sum(((oldX(1:6,:)-actual)./scale6).^2));
    be=be+sum(sum(((newX(1:6,:)-actual)./scale6).^2));
    clearance=v8_clearance(m,newX,c);bad=v8_stability(newX,U,clearance,c);
    if any(bad(:))
        event.reason='Held-input rollout left operating envelope';event.seconds=toc(checkClock);return;
    end
end
event.oldRolloutError=ae;event.newRolloutError=be;
if toc(checkClock)>c.learningBudget
    event.reason='Validation budget exceeded';
elseif be>1.05*ae+1e-6
    event.reason='Held-input multistep prediction worsened';
else
    event.accepted=true;event.reason='Passed held-out one-step and multistep tests';
end
event.seconds=toc(checkClock);
end
